package com.network.com.services.customer.cart;



import com.network.com.dto.AddProductInCartDto;
import com.network.com.dto.OrderDto;
import org.springframework.http.ResponseEntity;

public interface CartService {
    ResponseEntity<?> addProductToCart(AddProductInCartDto addProductInCartDto);

    OrderDto getCartByUserId(Long userId);
}
