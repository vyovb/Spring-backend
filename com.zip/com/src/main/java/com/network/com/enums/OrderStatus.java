package com.network.com.enums;

public enum OrderStatus {
    Pending,
    Placed,
    Shipped,
    Delivered,
}
