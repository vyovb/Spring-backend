package com.network.com.dto;


import lombok.Data;

@Data
public class CategDto {

    private Long id;
    private  String name;
    private String description;
}
