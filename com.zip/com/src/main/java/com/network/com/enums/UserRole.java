package com.network.com.enums;

public enum UserRole {
    ADMIN,
    CUSTOMER,
}
