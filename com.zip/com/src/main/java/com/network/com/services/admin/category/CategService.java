package com.network.com.services.admin.category;

import com.network.com.dto.CategDto;
import com.network.com.entity.Category;

import java.util.List;

public interface CategService{
    Category createCategory(CategDto categDto);
    List<Category> getAllCategories();
}
